module.exports = {
  '{,src/**/}*.{json,md,yml,java,ts,css,scss}': ['prettier --write', 'git add']
};
