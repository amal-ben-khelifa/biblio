/**
 * Service layer beans.
 */
package com.mycompany.biblotheque.service;
