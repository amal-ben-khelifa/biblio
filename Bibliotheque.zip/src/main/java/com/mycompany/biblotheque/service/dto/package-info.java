/**
 * Data Transfer Objects.
 */
package com.mycompany.biblotheque.service.dto;
