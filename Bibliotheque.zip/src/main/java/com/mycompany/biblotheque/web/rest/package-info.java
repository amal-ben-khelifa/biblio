/**
 * Spring MVC REST controllers.
 */
package com.mycompany.biblotheque.web.rest;
