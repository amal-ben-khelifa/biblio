/**
 * Spring Security configuration.
 */
package com.mycompany.biblotheque.security;
