/**
 * Spring Framework configuration files.
 */
package com.mycompany.biblotheque.config;
