/**
 * JPA domain objects.
 */
package com.mycompany.biblotheque.domain;
