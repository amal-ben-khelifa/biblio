/**
 * Spring Data JPA repositories.
 */
package com.mycompany.biblotheque.repository;
